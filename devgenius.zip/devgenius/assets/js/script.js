/**
 * DEVGENIUS - Premium Developer Showcase Script
 * Pure Vanilla JavaScript implementation for interactive effects,
 * 3D visual interaction, stats counting, and carousel controls.
 */

document.addEventListener('DOMContentLoaded', () => {
  'use strict';

  // Check user preference for reduced motion
  const prefersReducedMotion = window.matchMedia('(prefers-reduced-motion: reduce)').matches;

  /* ==========================================================================
     01. Ambient Particle Generator
     ========================================================================== */
  const initParticles = () => {
    const container = document.getElementById('particles-container');
    if (!container || prefersReducedMotion) return;

    const particleCount = window.innerWidth < 768 ? 15 : 30;

    for (let i = 0; i < particleCount; i++) {
      const particle = document.createElement('div');
      particle.className = 'particle';

      const size = Math.random() * 3 + 1;
      const left = Math.random() * 100;
      const duration = Math.random() * 15 + 10;
      const delay = Math.random() * 10;

      particle.style.cssText = `
        width: ${size}px;
        height: ${size}px;
        left: ${left}%;
        bottom: -20px;
        animation-duration: ${duration}s;
        animation-delay: ${delay}s;
      `;

      container.appendChild(particle);
    }
  };

  /* ==========================================================================
     02. Sticky Floating Navbar & Mobile Menu Toggle
     ========================================================================== */
  const initNavigation = () => {
    const navbar = document.getElementById('navbar');
    const hamburgerBtn = document.getElementById('hamburgerBtn');
    const navMenu = document.getElementById('navMenu');
    const navLinks = document.querySelectorAll('.nav-link');

    // Navbar translucency on scroll
    const handleScroll = () => {
      if (window.scrollY > 40) {
        navbar?.classList.add('scrolled');
      } else {
        navbar?.classList.remove('scrolled');
      }
    };

    window.addEventListener('scroll', handleScroll, { passive: true });
    handleScroll();

    // Hamburger Mobile Menu Toggle
    if (hamburgerBtn && navMenu) {
      hamburgerBtn.addEventListener('click', () => {
        const isOpen = navMenu.classList.toggle('open');
        hamburgerBtn.classList.toggle('active', isOpen);
        hamburgerBtn.setAttribute('aria-expanded', isOpen ? 'true' : 'false');
        document.body.style.overflow = isOpen ? 'hidden' : '';
      });

      // Close menu when clicking any nav link
      navLinks.forEach(link => {
        link.addEventListener('click', () => {
          navMenu.classList.remove('open');
          hamburgerBtn.classList.remove('active');
          hamburgerBtn.setAttribute('aria-expanded', 'false');
          document.body.style.overflow = '';
        });
      });
    }

    // Active Section Indicator on Scroll
    const sections = document.querySelectorAll('section[id]');
    const highlightActiveNav = () => {
      const scrollY = window.pageYOffset;

      sections.forEach(current => {
        const sectionHeight = current.offsetHeight;
        const sectionTop = current.offsetTop - 120;
        const sectionId = current.getAttribute('id');
        const navLink = document.querySelector(`.nav-link[href*="${sectionId}"]`);

        if (scrollY > sectionTop && scrollY <= sectionTop + sectionHeight) {
          navLink?.classList.add('active');
        } else {
          navLink?.classList.remove('active');
        }
      });
    };

    window.addEventListener('scroll', highlightActiveNav, { passive: true });
  };

  /* ==========================================================================
     03. Hero Interactive 3D Parallax Scene
     ========================================================================== */
  const initHero3D = () => {
    const heroSection = document.getElementById('home');
    const scene = document.getElementById('scene3d');
    const layers = document.querySelectorAll('#scene3d .layer');

    if (!heroSection || !scene || layers.length === 0 || prefersReducedMotion) return;

    let targetX = 0;
    let targetY = 0;
    let currentX = 0;
    let currentY = 0;

    const handleMouseMove = (e) => {
      const rect = heroSection.getBoundingClientRect();
      const centerX = rect.left + rect.width / 2;
      const centerY = rect.top + rect.height / 2;

      targetX = (e.clientX - centerX) / (rect.width / 2);
      targetY = (e.clientY - centerY) / (rect.height / 2);
    };

    const updateParallax = () => {
      // Smooth interpolation (lerp)
      currentX += (targetX - currentX) * 0.08;
      currentY += (targetY - currentY) * 0.08;

      const rotateY = currentX * 12;
      const rotateX = -currentY * 12;

      scene.style.transform = `rotateX(${rotateX}deg) rotateY(${rotateY}deg)`;

      layers.forEach(layer => {
        const depth = parseFloat(layer.getAttribute('data-depth') || '0.1');
        const translateX = currentX * depth * 100;
        const translateY = currentY * depth * 100;

        layer.style.transform = `translate3d(${translateX}px, ${translateY}px, ${depth * 150}px)`;
      });

      requestAnimationFrame(updateParallax);
    };

    heroSection.addEventListener('mousemove', handleMouseMove);
    heroSection.addEventListener('mouseleave', () => {
      targetX = 0;
      targetY = 0;
    });

    updateParallax();
  };

  /* ==========================================================================
     04. IntersectionObserver Scroll Reveal & Stats Counter
     ========================================================================== */
  const initScrollObservers = () => {
    // Reveal Elements Observer
    const fadeElements = document.querySelectorAll('.fade-in');
    const revealObserver = new IntersectionObserver((entries, observer) => {
      entries.forEach(entry => {
        if (entry.isIntersecting) {
          entry.target.classList.add('visible');
          observer.unobserve(entry.target);
        }
      });
    }, { threshold: 0.15, rootMargin: '0px 0px -50px 0px' });

    fadeElements.forEach(el => revealObserver.observe(el));

    // Stats Counter Observer
    const statNumbers = document.querySelectorAll('.stat-number');
    let animatedStats = false;

    const animateNumber = (el) => {
      const target = parseInt(el.getAttribute('data-target') || '0', 10);
      const padLength = parseInt(el.getAttribute('data-pad') || '0', 10);
      const duration = 2000;
      const frameDuration = 1000 / 60;
      const totalFrames = Math.round(duration / frameDuration);
      let frame = 0;

      const counter = setInterval(() => {
        frame++;
        const progress = frame / totalFrames;
        // Ease out quad formula
        const currentCount = Math.round(target * (1 - Math.pow(1 - progress, 3)));

        let formattedValue = currentCount.toString();
        if (padLength > 0) {
          formattedValue = formattedValue.padStart(padLength, '0');
        }

        el.textContent = formattedValue;

        if (frame === totalFrames) {
          clearInterval(counter);
          let finalFormatted = target.toString();
          if (padLength > 0) {
            finalFormatted = finalFormatted.padStart(padLength, '0');
          }
          el.textContent = finalFormatted;
        }
      }, frameDuration);
    };

    const statsObserver = new IntersectionObserver((entries, observer) => {
      entries.forEach(entry => {
        if (entry.isIntersecting && !animatedStats) {
          animatedStats = true;
          statNumbers.forEach(num => animateNumber(num));
          observer.disconnect();
        }
      });
    }, { threshold: 0.3 });

    const statsSection = document.querySelector('.stats-section');
    if (statsSection) {
      statsObserver.observe(statsSection);
    }
  };

  /* ==========================================================================
     05. Project Showcase Horizontal Slider / Carousel
     ========================================================================== */
  const initProjectSlider = () => {
    const sliderContainer = document.getElementById('projectSlider');
    const sliderTrack = document.getElementById('sliderTrack');
    const prevBtn = document.getElementById('sliderPrev');
    const nextBtn = document.getElementById('sliderNext');
    const dotsContainer = document.getElementById('sliderDots');

    if (!sliderTrack || !sliderContainer) return;

    const cards = Array.from(sliderTrack.children);
    let currentIndex = 0;
    let autoplayInterval = null;
    let isDragging = false;
    let startX = 0;
    let currentTranslate = 0;
    let prevTranslate = 0;
    let animationID = 0;

    const getVisibleCards = () => (window.innerWidth <= 1024 ? 1 : 2);
    const getMaxIndex = () => Math.max(0, cards.length - getVisibleCards());

    // Create pagination dots
    const createDots = () => {
      if (!dotsContainer) return;
      dotsContainer.innerHTML = '';
      const totalDots = getMaxIndex() + 1;

      for (let i = 0; i < totalDots; i++) {
        const dot = document.createElement('div');
        dot.className = `dot-item ${i === currentIndex ? 'active' : ''}`;
        dot.addEventListener('click', () => goToSlide(i));
        dotsContainer.appendChild(dot);
      }
    };

    const updateDots = () => {
      if (!dotsContainer) return;
      const dots = dotsContainer.querySelectorAll('.dot-item');
      dots.forEach((dot, idx) => {
        dot.classList.toggle('active', idx === currentIndex);
      });
    };

    const updateSliderPosition = () => {
      if (cards.length === 0) return;
      const cardWidth = cards[0].offsetWidth;
      const gap = 30; // Matches CSS gap
      currentTranslate = -currentIndex * (cardWidth + gap);
      prevTranslate = currentTranslate;
      sliderTrack.style.transform = `translateX(${currentTranslate}px)`;
      updateDots();
    };

    const goToSlide = (index) => {
      const maxIndex = getMaxIndex();
      if (index < 0) {
        currentIndex = maxIndex;
      } else if (index > maxIndex) {
        currentIndex = 0;
      } else {
        currentIndex = index;
      }
      updateSliderPosition();
    };

    // Navigation buttons
    nextBtn?.addEventListener('click', () => {
      goToSlide(currentIndex + 1);
      resetAutoplay();
    });

    prevBtn?.addEventListener('click', () => {
      goToSlide(currentIndex - 1);
      resetAutoplay();
    });

    // Autoplay feature
    const startAutoplay = () => {
      if (prefersReducedMotion) return;
      stopAutoplay();
      autoplayInterval = setInterval(() => {
        goToSlide(currentIndex + 1);
      }, 5000);
    };

    const stopAutoplay = () => {
      if (autoplayInterval) clearInterval(autoplayInterval);
    };

    const resetAutoplay = () => {
      stopAutoplay();
      startAutoplay();
    };

    sliderContainer.addEventListener('mouseenter', stopAutoplay);
    sliderContainer.addEventListener('mouseleave', startAutoplay);

    // Touch & Mouse Dragging Events
    const touchStart = (index) => (event) => {
      isDragging = true;
      startX = getPositionX(event);
      stopAutoplay();
      animationID = requestAnimationFrame(animation);
      sliderTrack.style.transition = 'none';
    };

    const touchMove = (event) => {
      if (!isDragging) return;
      const currentPosition = getPositionX(event);
      currentTranslate = prevTranslate + currentPosition - startX;
    };

    const touchEnd = () => {
      isDragging = false;
      cancelAnimationFrame(animationID);
      sliderTrack.style.transition = 'transform 0.5s cubic-bezier(0.16, 1, 0.3, 1)';

      const movedBy = currentTranslate - prevTranslate;
      if (movedBy < -100 && currentIndex < getMaxIndex()) {
        currentIndex += 1;
      } else if (movedBy > 100 && currentIndex > 0) {
        currentIndex -= 1;
      }

      updateSliderPosition();
      startAutoplay();
    };

    const getPositionX = (event) => {
      return event.type.includes('mouse') ? event.clientX : event.touches[0].clientX;
    };

    const animation = () => {
      sliderTrack.style.transform = `translateX(${currentTranslate}px)`;
      if (isDragging) requestAnimationFrame(animation);
    };

    cards.forEach((card) => {
      const cardImg = card.querySelector('img');
      cardImg?.addEventListener('dragstart', (e) => e.preventDefault());

      // Touch events
      card.addEventListener('touchstart', touchStart(currentIndex), { passive: true });
      card.addEventListener('touchend', touchEnd);
      card.addEventListener('touchmove', touchMove, { passive: true });

      // Mouse events
      card.addEventListener('mousedown', touchStart(currentIndex));
      card.addEventListener('mouseup', touchEnd);
      card.addEventListener('mouseleave', () => {
        if (isDragging) touchEnd();
      });
      card.addEventListener('mousemove', touchMove);
    });

    window.addEventListener('resize', () => {
      createDots();
      updateSliderPosition();
    });

    createDots();
    updateSliderPosition();
    startAutoplay();
  };

  /* ==========================================================================
     06. 3D Tilt Effect for Glass Cards
     ========================================================================== */
  const init3DTilt = () => {
    const tiltCards = document.querySelectorAll('[data-tilt]');

    if (prefersReducedMotion || window.innerWidth < 768) return;

    tiltCards.forEach(card => {
      card.addEventListener('mousemove', (e) => {
        const rect = card.getBoundingClientRect();
        const x = e.clientX - rect.left;
        const y = e.clientY - rect.top;

        const centerX = rect.width / 2;
        const centerY = rect.height / 2;

        const rotateX = ((y - centerY) / centerY) * -8;
        const rotateY = ((x - centerX) / centerX) * 8;

        card.style.transform = `perspective(1000px) rotateX(${rotateX}deg) rotateY(${rotateY}deg) translateZ(10px)`;
      });

      card.addEventListener('mouseleave', () => {
        card.style.transform = 'perspective(1000px) rotateX(0deg) rotateY(0deg) translateZ(0)';
      });
    });
  };

  /* ==========================================================================
     07. Smooth Scroll for Anchor Links
     ========================================================================== */
  const initSmoothScroll = () => {
    document.querySelectorAll('a[href^="#"]').forEach(anchor => {
      anchor.addEventListener('click', function (e) {
        const targetId = this.getAttribute('href');
        if (targetId === '#') return;

        const targetElement = document.querySelector(targetId);
        if (targetElement) {
          e.preventDefault();
          const navbarHeight = 90;
          const targetPosition = targetElement.getBoundingClientRect().top + window.pageYOffset - navbarHeight;

          window.scrollTo({
            top: targetPosition,
            behavior: prefersReducedMotion ? 'auto' : 'smooth'
          });
        }
      });
    });
  };

  /* Initialize All Modules */
  initParticles();
  initNavigation();
  initHero3D();
  initScrollObservers();
  initProjectSlider();
  init3DTilt();
  initSmoothScroll();
});
